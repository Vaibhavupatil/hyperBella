package com.sapours.mini_project_5_0.pojo;

public class emailpojo {
	public emailpojo() {
		super();
		// TODO Auto-generated constructor stub
	}

	private String to;

	public emailpojo(String to) {
		super();
		this.to = to;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}
}
